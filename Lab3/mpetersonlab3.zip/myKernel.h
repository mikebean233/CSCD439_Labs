
// myKernel.h
#ifndef mykernel_h
#define mykernel_h

__global__ void kernel( int *a, int dimx, int dimy );
__global__ void kernel2( int *a, int dimx, int dimy );
__global__ void kernel3( int *a, int dimx, int dimy );
__global__ void kernel4( int *a, int dimx, int dimy );
__global__ void kernel5( int *a, int dimx, int dimy );
__global__ void kernel6( int *a, int dimx, int dimy );

#endif

